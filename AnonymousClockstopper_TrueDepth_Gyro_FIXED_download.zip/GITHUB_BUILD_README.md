# GitHub Actions APK build

The included workflow is `.github/workflows/build-apk.yml`.

It checks out the project, sets up Java 17 and Android SDK 35, installs Gradle 8.9, runs `clean assembleDebug`, verifies the APK exists, and uploads `app/build/outputs/apk/debug/app-debug.apk` as the artifact `AnonymousClockstopper-debug-apk`.

A completed workflow run is the verification step. The source ZIP itself is not an installable APK.
