package com.example.motogyro

import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class GyroWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = GyroEngine()

    private inner class GyroEngine : Engine() {
        private var renderer: WallpaperRenderer? = null
        private var visible = false

        private fun syncRenderer() {
            val current = renderer ?: return
            if (visible && surfaceHolder.surface?.isValid == true) current.start()
            else current.stop()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            this.visible = visible
            syncRenderer()
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            renderer?.stop()
            renderer = WallpaperRenderer(this@GyroWallpaperService, holder)
            syncRenderer()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            renderer?.resize(width, height)
            syncRenderer()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            renderer?.stop()
            renderer = null
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            renderer?.stop()
            renderer = null
            super.onDestroy()
        }
    }
}
