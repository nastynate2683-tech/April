# Anonymous Clockstopper — True Depth Gyro

Android live-wallpaper source project for a red/gold glass-diorama scene with six alpha-composited depth planes and smooth rotation-vector parallax.

## What is included

- `scene_color.png` and `scene_depth.png` source/reference assets
- `depth_layer_1.png` through `depth_layer_5.png` plus `glass_reflection.png`
- Android `WallpaperService` implementation and a frame-synchronized renderer
- `MotionController` using Android rotation-vector sensor fusion with frame-rate-independent smoothing
- GitHub Actions workflow to build and upload a debug APK

## Build verification status

The source and resources have been audited and the renderer/controller property mismatch has been corrected (`motion.x` / `motion.y`). The Android build itself has **not yet been run in this environment** because no Android SDK/Gradle installation is available and external downloads are blocked. Do not treat this source ZIP as an APK or claim a successful build until the GitHub Actions run completes successfully.

## Build in GitHub Actions

Once these project files are committed to the repository's `main` branch, open **Actions → Build Android APK → Run workflow**. A successful run creates the artifact `AnonymousClockstopper-debug-apk`, containing `app-debug.apk`.

The workflow uses Java 17, Android SDK 35, Android Gradle Plugin 8.7.3, and Gradle 8.9. The APK is a debug build intended for direct testing on the target Android phone.

## Install

Install `app-debug.apk`, open **Anonymous Clockstopper — True Depth Gyro**, choose the live-wallpaper preview, and apply it. If Android opens the system wallpaper picker, select the wallpaper and confirm.
